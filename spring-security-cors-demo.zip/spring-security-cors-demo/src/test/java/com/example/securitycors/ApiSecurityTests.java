package com.example.securitycors;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class ApiSecurityTests {
    @Autowired MockMvc mvc;

    @Test
    void publicEndpointNeedsNoLogin() throws Exception {
        mvc.perform(get("/api/public/hello"))
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

    @Test
    void privateEndpointRejectsAnonymousRequest() throws Exception {
        mvc.perform(get("/api/user/profile")).andExpect(status().isUnauthorized());
    }

    @Test
    void userCanAccessUserEndpoint() throws Exception {
        mvc.perform(get("/api/user/profile").with(httpBasic("user", "user123")))
            .andExpect(status().isOk());
    }

    @Test
    void regularUserCannotAccessAdminEndpoint() throws Exception {
        mvc.perform(get("/api/admin/dashboard").with(httpBasic("user", "user123")))
            .andExpect(status().isForbidden());
    }

    @Test
    void adminCanAccessAdminEndpoint() throws Exception {
        mvc.perform(get("/api/admin/dashboard").with(httpBasic("admin", "admin123")))
            .andExpect(status().isOk());
    }
}
