package com.example.securitycors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityCorsDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(SecurityCorsDemoApplication.class, args);
    }
}
