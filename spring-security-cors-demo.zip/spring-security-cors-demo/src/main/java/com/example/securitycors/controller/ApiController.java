package com.example.securitycors.controller;

import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ApiController {

    @GetMapping("/public/hello")
    public Map<String, String> publicEndpoint() {
        return Map.of("message", "Hello! This endpoint is public.");
    }

    @GetMapping("/user/profile")
    public Map<String, String> userEndpoint() {
        return Map.of("message", "You are authenticated.", "access", "USER");
    }

    @GetMapping("/admin/dashboard")
    public Map<String, String> adminEndpoint() {
        return Map.of("message", "Welcome to the admin dashboard.", "access", "ADMIN");
    }
}
